# Password Entropy Evaluator

A small, dependency-free web tool that scores a password by its **entropy** — how much randomness it actually contains — rather than just checking a few arbitrary rules like "has a number." It also estimates how long the password would realistically survive against a few different kinds of attacks.

Try it live: open `index.html` in a browser, or host it with GitHub Pages (see below).

## How it works

1. **Character pool.** The tool looks at which character classes are present — lowercase, uppercase, digits, symbols, or extended/unicode characters — and adds up the pool size (e.g. lowercase + digits = 36 possible characters per position).
2. **Raw entropy.** Entropy in bits is calculated as:

   ```
   bits = length × log2(pool size)
   ```

   This is the standard way to estimate how many attempts, in the worst case, a brute-force attacker would need.
3. **Pattern penalties.** Raw entropy overstates real-world strength, because humans don't pick characters randomly. The tool subtracts bits for:
   - Matching a list of extremely common passwords
   - Sequential runs (`abcd`, `4321`)
   - Keyboard-adjacent sequences (`qwerty`, `asdf`)
   - Repeated characters (`aaa`, `111`)
   - Repeated short blocks (`abcabcabc`)
4. **Crack-time estimates.** The adjusted entropy is converted into an estimated number of guesses (half the keyspace, the average case) and divided by four illustrative guessing rates: a rate-limited online login, an unthrottled online login, an offline attack against a slow hash like bcrypt, and an offline attack against a fast hash on GPU hardware.

Nothing is sent anywhere — all of this runs client-side in `script.js`.

## Rating scale

| Entropy (adjusted) | Rating      |
|---------------------|-------------|
| < 28 bits           | Very weak   |
| 28–35 bits          | Weak        |
| 36–59 bits          | Fair        |
| 60–79 bits          | Strong      |
| ≥ 80 bits           | Very strong |

## Project structure

```
.
├── index.html    # markup
├── styles.css    # styling
├── script.js     # entropy calculation + DOM wiring
└── README.md
```

## Running locally

No build step. Either open `index.html` directly, or serve it:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying with GitHub Pages

1. Push this repo to GitHub.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to "Deploy from a branch," pick `main` and `/ (root)`.
4. Your evaluator will be live at `https://<username>.github.io/<repo-name>/`.

## Notes and limitations

- This is an estimation tool, not a guarantee — it doesn't check passwords against real breach databases, and the crack-time figures are illustrative, not precise (real attackers optimize their guessing order, which this simple model doesn't account for).
- Entropy is a reasonable proxy for strength but isn't the whole story; a long, unique passphrase is usually both higher-entropy and easier to remember than a short string of random symbols.
- For production use cases, consider pairing an entropy estimate like this with a check against known breached passwords (e.g. the [Have I Been Pwned Passwords API](https://haveibeenpwned.com/Passwords)).

## License

MIT — do whatever you'd like with this.
